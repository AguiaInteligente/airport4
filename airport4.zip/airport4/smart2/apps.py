from django.apps import AppConfig


class Smart2Config(AppConfig):
    name = 'smart2'
